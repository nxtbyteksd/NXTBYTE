/**
 * Nxt Byte — Ultra-High-Performance Interactive Motion & 3D Engine
 * Fully hardware-accelerated, natural responsive scrolling, lightweight 3D depth,
 * interactive founder sandbox, team filtering, and micro-interactions.
 */
(() => {
  'use strict';

  // System & Accessibility Preferences
  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const isFinePointer = window.matchMedia('(pointer: fine)').matches;

  // DOM Elements
  const header = document.getElementById('siteHeader');
  const scrollProgressBar = document.getElementById('scrollProgressBar');
  const mobileMenuBtn = document.getElementById('mobileMenuBtn');
  const mobileDrawer = document.getElementById('mobileDrawer');
  const mobileNavLinks = document.querySelectorAll('.mobile-nav-link');
  const desktopNavLinks = document.querySelectorAll('.header-nav .nav-link');
  const sections = document.querySelectorAll('main section[id]');
  const backToTopBtn = document.getElementById('backToTopBtn');

  // Hero 3D Stage Elements
  const heroStage = document.querySelector('.hero-3d-stage');
  const heroCard = document.getElementById('hero3DCard');
  const heroCanvas = document.getElementById('hero3DCanvas');
  const heroBrandLockup = document.getElementById('heroBrandLockup');

  // Showcase 3D Elements
  const showcaseSection = document.getElementById('showcase');
  const showcaseDevice = document.getElementById('showcaseDevice');
  const chipLeft = document.getElementById('chipLeft');
  const chipRight = document.getElementById('chipRight');
  const showcaseTabBtns = document.querySelectorAll('.showcase-tab-btn');
  const screenPanels = document.querySelectorAll('.screen-panel');

  /* ==========================================================================
     1. NATURAL, HIGH-SPEED SCROLL & 3D PARALLAX (Zero-Delay Composited)
     ========================================================================== */
  let isTicking = false;

  const updateScrollState = () => {
    const scrollY = window.scrollY;
    const maxScroll = document.documentElement.scrollHeight - window.innerHeight;

    // 1. Top Progress Bar (GPU transform)
    if (scrollProgressBar && maxScroll > 0) {
      const progress = Math.min(Math.max(scrollY / maxScroll, 0), 1);
      scrollProgressBar.style.transform = `scaleX(${progress})`;
    }

    // 2. Header Background Transition
    if (header) {
      if (scrollY > 30) {
        header.classList.add('scrolled');
      } else {
        header.classList.remove('scrolled');
      }
    }

    // 3. Apple-Style 3D Showcase Perspective (GPU scale3d & rotateX/Y)
    if (showcaseSection && showcaseDevice && !prefersReducedMotion) {
      const rect = showcaseSection.getBoundingClientRect();
      const windowHeight = window.innerHeight;

      if (rect.top <= windowHeight && rect.bottom >= 0) {
        const totalDistance = windowHeight + rect.height;
        const currentDistance = windowHeight - rect.top;
        const progress = Math.min(Math.max(currentDistance / totalDistance, 0), 1);

        // Sinusoidal curve peaking in the center
        const centerOffset = Math.sin(progress * Math.PI);
        const rotateX = (1 - centerOffset) * 11;
        const rotateY = (1 - centerOffset) * -3;
        const scale = 0.94 + (centerOffset * 0.07);

        showcaseDevice.style.transform = `perspective(1000px) rotateX(${rotateX.toFixed(2)}deg) rotateY(${rotateY.toFixed(2)}deg) scale3d(${scale.toFixed(3)}, ${scale.toFixed(3)}, 1)`;

        if (chipLeft && chipRight) {
          const chipTranslate = (1 - centerOffset) * 28;
          const chipOpacity = Math.min(centerOffset * 1.6, 1);
          chipLeft.style.transform = `translate3d(${-chipTranslate}px, 0, 15px)`;
          chipLeft.style.opacity = chipOpacity;
          chipRight.style.transform = `translate3d(${chipTranslate}px, 0, 15px)`;
          chipRight.style.opacity = chipOpacity;
        }
      }
    }
  };

  // Passive, RAF-throttled scroll listener: never blocks main thread or user scrolling
  window.addEventListener('scroll', () => {
    if (!isTicking) {
      requestAnimationFrame(() => {
        updateScrollState();
        isTicking = false;
      });
      isTicking = true;
    }
  }, { passive: true });

  // Initial call
  updateScrollState();

  /* ==========================================================================
     2. HERO 3D INTERACTIVE PARTICLE & WIREFRAME CONSTELLATION
     ========================================================================== */
  if (heroCanvas && !prefersReducedMotion) {
    const ctx = heroCanvas.getContext('2d');
    let width = 0;
    let height = 0;
    let animId = null;
    let isHeroVisible = true;

    const resizeCanvas = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      width = heroCanvas.parentElement ? heroCanvas.parentElement.offsetWidth : window.innerWidth;
      height = heroCanvas.parentElement ? heroCanvas.parentElement.offsetHeight : window.innerHeight;
      heroCanvas.width = width * dpr;
      heroCanvas.height = height * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };

    window.addEventListener('resize', resizeCanvas, { passive: true });
    resizeCanvas();

    // 3D Nodes definition
    const nodeCount = Math.min(Math.max(Math.floor(width / 24), 28), 54);
    const nodes = [];
    const focalLength = 380;

    for (let i = 0; i < nodeCount; i++) {
      nodes.push({
        x: (Math.random() - 0.5) * width * 1.1,
        y: (Math.random() - 0.5) * height * 1.1,
        z: (Math.random() - 0.5) * 450,
        radius: Math.random() * 2.2 + 1.2,
        baseAlpha: Math.random() * 0.45 + 0.35,
        speedX: (Math.random() - 0.5) * 0.25,
        speedY: (Math.random() - 0.5) * 0.25,
        speedZ: (Math.random() - 0.5) * 0.35
      });
    }

    let targetRotY = 0;
    let targetRotX = 0;
    let curRotY = 0;
    let curRotX = 0;

    if (isFinePointer) {
      window.addEventListener('pointermove', (e) => {
        const x = (e.clientX / window.innerWidth - 0.5) * 0.35;
        const y = (e.clientY / window.innerHeight - 0.5) * 0.25;
        targetRotY = x;
        targetRotX = y;
      }, { passive: true });
    }

    const renderHero3D = () => {
      if (!isHeroVisible) return;

      ctx.clearRect(0, 0, width, height);

      curRotY += (targetRotY - curRotY) * 0.05 + 0.001;
      curRotX += (targetRotX - curRotX) * 0.05;

      const cosY = Math.cos(curRotY);
      const sinY = Math.sin(curRotY);
      const cosX = Math.cos(curRotX);
      const sinX = Math.sin(curRotX);

      const centerX = width / 2;
      const centerY = height / 2;

      // Update and project 3D nodes
      const projected = [];
      for (let i = 0; i < nodes.length; i++) {
        const n = nodes[i];
        n.x += n.speedX;
        n.y += n.speedY;
        n.z += n.speedZ;

        // Wrap around 3D box
        const boundX = width * 0.65;
        const boundY = height * 0.65;
        if (n.x < -boundX) n.x = boundX;
        if (n.x > boundX) n.x = -boundX;
        if (n.y < -boundY) n.y = boundY;
        if (n.y > boundY) n.y = -boundY;
        if (n.z < -225) n.z = 225;
        if (n.z > 225) n.z = -225;

        // 3D Rotation Matrix
        const x1 = n.x * cosY - n.z * sinY;
        const z1 = n.z * cosY + n.x * sinY;

        const y2 = n.y * cosX - z1 * sinX;
        const z2 = z1 * cosX + n.y * sinX;

        const depth = focalLength + z2;
        if (depth > 20) {
          const scale = focalLength / depth;
          const px = centerX + x1 * scale;
          const py = centerY + y2 * scale;
          const pRadius = Math.max(n.radius * scale, 0.5);
          const alpha = Math.min(Math.max((z2 + 225) / 450, 0.15), 0.95) * n.baseAlpha;

          projected.push({ x: px, y: py, z: z2, scale, radius: pRadius, alpha });
        }
      }

      // Draw connecting luminous lines
      ctx.lineWidth = 1;
      for (let i = 0; i < projected.length; i++) {
        for (let j = i + 1; j < projected.length; j++) {
          const p1 = projected[i];
          const p2 = projected[j];
          const dx = p1.x - p2.x;
          const dy = p1.y - p2.y;
          const dist = Math.sqrt(dx * dx + dy * dy);

          if (dist < 125) {
            const lineAlpha = (1 - dist / 125) * Math.min(p1.alpha, p2.alpha) * 0.55;
            ctx.strokeStyle = `rgba(168, 85, 247, ${lineAlpha.toFixed(3)})`;
            ctx.beginPath();
            ctx.moveTo(p1.x, p1.y);
            ctx.lineTo(p2.x, p2.y);
            ctx.stroke();
          }
        }
      }

      // Draw glowing nodes
      for (let i = 0; i < projected.length; i++) {
        const p = projected[i];
        const glowRadius = p.radius * 3.6;
        const grad = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, glowRadius);
        grad.addColorStop(0, `rgba(216, 180, 254, ${p.alpha.toFixed(2)})`);
        grad.addColorStop(0.4, `rgba(168, 85, 247, ${(p.alpha * 0.5).toFixed(2)})`);
        grad.addColorStop(1, 'rgba(139, 92, 246, 0)');

        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.arc(p.x, p.y, glowRadius, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = `rgba(255, 255, 255, ${Math.min(p.alpha * 1.3, 1).toFixed(2)})`;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius * 0.75, 0, Math.PI * 2);
        ctx.fill();
      }

      animId = requestAnimationFrame(renderHero3D);
    };

    // Pause canvas execution when hero is off-screen
    if ('IntersectionObserver' in window) {
      const heroObserver = new IntersectionObserver((entries) => {
        isHeroVisible = entries[0].isIntersecting;
        if (isHeroVisible && !animId) {
          animId = requestAnimationFrame(renderHero3D);
        } else if (!isHeroVisible && animId) {
          cancelAnimationFrame(animId);
          animId = null;
        }
      }, { threshold: 0.05 });
      heroObserver.observe(heroCanvas);
    } else {
      animId = requestAnimationFrame(renderHero3D);
    }
  }

  /* ==========================================================================
     HERO 3D PERSPECTIVE MOUSE PARALLAX & TILT (Hardware-Accelerated)
     ========================================================================== */
  if (heroStage && heroCard && isFinePointer && !prefersReducedMotion) {
    let heroRaf = null;

    heroStage.addEventListener('pointermove', (e) => {
      if (heroRaf) return;
      heroRaf = requestAnimationFrame(() => {
        const rect = heroStage.getBoundingClientRect();
        const x = (e.clientX - rect.left) / rect.width - 0.5;
        const y = (e.clientY - rect.top) / rect.height - 0.5;

        heroCard.style.transform = `rotateY(${x * 6}deg) rotateX(${y * -6}deg) translateZ(10px)`;

        if (heroBrandLockup) {
          heroBrandLockup.style.transform = `rotateY(${x * 12}deg) rotateX(${y * -12}deg) translateZ(28px)`;
        }
        heroRaf = null;
      });
    }, { passive: true });

    heroStage.addEventListener('pointerleave', () => {
      heroCard.style.transform = 'rotateY(0deg) rotateX(0deg) translateZ(0)';
      if (heroBrandLockup) {
        heroBrandLockup.style.transform = 'rotateY(0deg) rotateX(0deg) translateZ(0)';
      }
    });
  }

  /* ==========================================================================
     3. NAVIGATION ACTIVE LINK TRACKING
     ========================================================================== */
  if ('IntersectionObserver' in window && sections.length > 0) {
    const navObserver = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          const id = entry.target.getAttribute('id');
          desktopNavLinks.forEach((link) => {
            const href = link.getAttribute('href');
            if (href === `#${id}`) {
              link.classList.add('active');
            } else {
              link.classList.remove('active');
            }
          });
        }
      });
    }, {
      rootMargin: '-25% 0px -45% 0px',
      threshold: 0.1
    });

    sections.forEach((section) => navObserver.observe(section));
  }

  /* ==========================================================================
     4. FAST, NON-BLOCKING REVEAL ANIMATIONS
     ========================================================================== */
  const revealItems = document.querySelectorAll('.reveal-item');
  if ('IntersectionObserver' in window && !prefersReducedMotion) {
    const revealObserver = new IntersectionObserver((entries, observer) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-revealed');
          observer.unobserve(entry.target);
        }
      });
    }, {
      threshold: 0.08,
      rootMargin: '0px 0px -20px 0px'
    });

    revealItems.forEach((el) => revealObserver.observe(el));
  } else {
    revealItems.forEach((el) => el.classList.add('is-revealed'));
  }

  /* ==========================================================================
     5. HERO STATS COUNTER ANIMATION
     ========================================================================== */
  const statNumbers = document.querySelectorAll('.stat-number[data-target]');
  let statsTriggered = false;

  const runCounterAnimation = () => {
    if (statsTriggered) return;
    statsTriggered = true;

    statNumbers.forEach((counter) => {
      const target = Number(counter.dataset.target) || 0;
      const suffix = counter.dataset.suffix || '+';
      const duration = 1200;
      const startTime = performance.now();

      const updateCounter = (currentTime) => {
        const elapsed = currentTime - startTime;
        const progress = Math.min(elapsed / duration, 1);
        const easeOut = 1 - Math.pow(1 - progress, 3);
        const currentVal = Math.round(target * easeOut);
        counter.textContent = `${currentVal}${suffix}`;

        if (progress < 1) {
          requestAnimationFrame(updateCounter);
        }
      };
      requestAnimationFrame(updateCounter);
    });
  };

  const statsStrip = document.querySelector('.hero-stats-strip');
  if (statsStrip && 'IntersectionObserver' in window && !prefersReducedMotion) {
    const statsObserver = new IntersectionObserver((entries) => {
      if (entries[0].isIntersecting) {
        runCounterAnimation();
        statsObserver.disconnect();
      }
    }, { threshold: 0.25 });
    statsObserver.observe(statsStrip);
  } else {
    runCounterAnimation();
  }

  /* ==========================================================================
     6. SHOWCASE INTERACTIVE TABS & AUTO-CYCLE
     ========================================================================== */
  const tabKeys = ['genesis', 'sprint', 'traction'];
  let currentTabIndex = 0;
  let autoCycleInterval = null;

  const setActiveShowcaseTab = (key) => {
    showcaseTabBtns.forEach((btn) => {
      if (btn.dataset.tab === key) {
        btn.classList.add('is-active');
      } else {
        btn.classList.remove('is-active');
      }
    });

    screenPanels.forEach((panel) => {
      if (panel.id === `panel-${key}`) {
        panel.classList.add('is-active');
      } else {
        panel.classList.remove('is-active');
      }
    });
  };

  showcaseTabBtns.forEach((btn, index) => {
    btn.addEventListener('click', () => {
      const tabKey = btn.dataset.tab;
      currentTabIndex = index;
      setActiveShowcaseTab(tabKey);
      clearInterval(autoCycleInterval);
    });
  });

  if (!prefersReducedMotion) {
    autoCycleInterval = setInterval(() => {
      currentTabIndex = (currentTabIndex + 1) % tabKeys.length;
      setActiveShowcaseTab(tabKeys[currentTabIndex]);
    }, 7000);

    showcaseDevice?.addEventListener('mouseenter', () => clearInterval(autoCycleInterval));
  }

  /* ==========================================================================
     7. TEAM DIRECTORY CATEGORY FILTERING
     ========================================================================== */
  const filterBtns = document.querySelectorAll('.team-filter-btn');
  const teamCards = document.querySelectorAll('.team-card');

  filterBtns.forEach((btn) => {
    btn.addEventListener('click', () => {
      filterBtns.forEach((b) => b.classList.remove('is-active'));
      btn.classList.add('is-active');

      const filterValue = btn.dataset.filter;

      teamCards.forEach((card) => {
        const cardCategory = card.dataset.category || '';
        if (filterValue === 'all' || cardCategory.includes(filterValue)) {
          card.classList.remove('is-hidden');
          requestAnimationFrame(() => {
            card.style.opacity = '1';
            card.style.transform = 'translate3d(0, 0, 0)';
          });
        } else {
          card.style.opacity = '0';
          card.style.transform = 'translate3d(0, 10px, 0)';
          setTimeout(() => {
            card.classList.add('is-hidden');
          }, 200);
        }
      });
    });
  });

  /* ==========================================================================
     8. INTERACTIVE IDEA FEASIBILITY SANDBOX
     ========================================================================== */
  const domainBtns = document.querySelectorAll('.domain-radio-btn');
  const stageBtns = document.querySelectorAll('.stage-btn');
  const sandboxScoreEl = document.getElementById('sandboxScore');
  const sandboxStatusEl = document.getElementById('sandboxStatus');
  const sandboxBatchEl = document.getElementById('sandboxBatch');
  const sandboxTimeEl = document.getElementById('sandboxTime');
  const sandboxMentorEl = document.getElementById('sandboxMentor');

  let selectedDomain = 'ai';
  let selectedStage = 'napkin';

  const sandboxDatabase = {
    ai: {
      title: 'Batch 2026 - AI Track',
      mentor: 'Albin Rajesh (Tech Lead)',
      scores: { napkin: 86, wireframe: 92, mvp: 97 },
      times: { napkin: '7 - 10 Days', wireframe: '5 - 7 Days', mvp: '3 - 5 Days' },
      statuses: { napkin: 'Fast-Track AI Sprint', wireframe: 'High Viability Prototype', mvp: 'Ready for Seed Angels' }
    },
    fintech: {
      title: 'Batch 2026 - Fintech & Web3',
      mentor: 'Alan Albin (Developer)',
      scores: { napkin: 82, wireframe: 89, mvp: 95 },
      times: { napkin: '10 - 14 Days', wireframe: '7 - 10 Days', mvp: '4 - 6 Days' },
      statuses: { napkin: 'Compliance & Schema Review', wireframe: 'Architecture Sprint', mvp: 'Campus Beta Ready' }
    },
    iot: {
      title: 'Batch 2026 - Hardware & IoT',
      mentor: 'Hijas Aboobacker (Developer)',
      scores: { napkin: 80, wireframe: 87, mvp: 93 },
      times: { napkin: '14 - 21 Days', wireframe: '10 - 14 Days', mvp: '7 - 10 Days' },
      statuses: { napkin: 'Lab & Component Allocation', wireframe: 'Firmware Prototype', mvp: 'NEC Hardware Category' }
    },
    edtech: {
      title: 'Batch 2026 - EdTech & Consumer',
      mentor: 'Shuhaib Muhammed (Developer)',
      scores: { napkin: 88, wireframe: 94, mvp: 98 },
      times: { napkin: '5 - 7 Days', wireframe: '4 - 5 Days', mvp: '48 Hours' },
      statuses: { napkin: 'Campus Beta Launch', wireframe: 'Traction Testing', mvp: 'Immediate Pilot Rollout' }
    }
  };

  const updateSandbox = () => {
    const config = sandboxDatabase[selectedDomain] || sandboxDatabase.ai;
    const targetScore = config.scores[selectedStage] || 90;
    const statusText = config.statuses[selectedStage];
    const timeText = config.times[selectedStage];

    if (sandboxScoreEl) {
      let currentDisplay = Number(sandboxScoreEl.textContent) || 85;
      const step = targetScore > currentDisplay ? 1 : -1;
      const scoreInterval = setInterval(() => {
        if (currentDisplay === targetScore) {
          clearInterval(scoreInterval);
        } else {
          currentDisplay += step;
          sandboxScoreEl.textContent = currentDisplay;
        }
      }, 15);
    }

    if (sandboxStatusEl) sandboxStatusEl.textContent = statusText;
    if (sandboxBatchEl) sandboxBatchEl.textContent = config.title;
    if (sandboxTimeEl) sandboxTimeEl.textContent = timeText;
    if (sandboxMentorEl) sandboxMentorEl.textContent = config.mentor;
  };

  domainBtns.forEach((btn) => {
    btn.addEventListener('click', () => {
      domainBtns.forEach((b) => b.classList.remove('is-selected'));
      btn.classList.add('is-selected');
      selectedDomain = btn.dataset.domain;
      updateSandbox();
    });
  });

  stageBtns.forEach((btn) => {
    btn.addEventListener('click', () => {
      stageBtns.forEach((b) => b.classList.remove('is-selected'));
      btn.classList.add('is-selected');
      selectedStage = btn.dataset.stage;
      updateSandbox();
    });
  });

  /* ==========================================================================
     9. UNIVERSAL 3D CARD HOVER, TILT & SPECULAR LIGHTING ENGINE
     ========================================================================== */
  if (isFinePointer && !prefersReducedMotion) {
    const tiltCards = document.querySelectorAll(
      '.pillar-card, .team-card, .pipeline-card, .mv-card-premium, .advisor-card-premium, .sandbox-container, .cta-banner, .eco-logo-badge, .footer-instagram-card'
    );

    tiltCards.forEach((card) => {
      // Inject specular glare overlay if missing
      if (!card.querySelector('.card-glare')) {
        const glare = document.createElement('div');
        glare.className = 'card-glare';
        glare.setAttribute('aria-hidden', 'true');
        card.appendChild(glare);
      }

      let cardRaf = null;

      card.addEventListener('pointermove', (e) => {
        if (cardRaf) return;
        cardRaf = requestAnimationFrame(() => {
          const rect = card.getBoundingClientRect();
          const x = (e.clientX - rect.left) / rect.width - 0.5;
          const y = (e.clientY - rect.top) / rect.height - 0.5;

          const maxTilt = card.classList.contains('team-card') ? 7 : (card.classList.contains('footer-instagram-card') ? 6 : 5);
          const rotX = -y * maxTilt;
          const rotY = x * maxTilt;

          card.style.transform = `perspective(1000px) rotateX(${rotX.toFixed(2)}deg) rotateY(${rotY.toFixed(2)}deg) translate3d(0, -6px, 14px)`;
          card.style.setProperty('--glare-x', `${(e.clientX - rect.left).toFixed(1)}px`);
          card.style.setProperty('--glare-y', `${(e.clientY - rect.top).toFixed(1)}px`);
          card.style.setProperty('--mouse-x', `${(e.clientX - rect.left).toFixed(1)}px`);
          card.style.setProperty('--mouse-y', `${(e.clientY - rect.top).toFixed(1)}px`);

          cardRaf = null;
        });
      }, { passive: true });

      card.addEventListener('pointerleave', () => {
        card.style.transform = 'perspective(1000px) rotateX(0deg) rotateY(0deg) translate3d(0, 0, 0)';
      });
    });
  }

  /* ==========================================================================
     10. MOBILE NAVIGATION DRAWER
     ========================================================================== */
  const toggleMobileMenu = (forceClose = false) => {
    const isExpanded = mobileMenuBtn?.getAttribute('aria-expanded') === 'true';
    const shouldOpen = forceClose ? false : !isExpanded;

    mobileMenuBtn?.setAttribute('aria-expanded', String(shouldOpen));
    mobileDrawer?.setAttribute('aria-hidden', String(!shouldOpen));
    mobileDrawer?.classList.toggle('is-open', shouldOpen);
    document.body.style.overflow = shouldOpen ? 'hidden' : '';
  };

  mobileMenuBtn?.addEventListener('click', () => toggleMobileMenu());

  mobileNavLinks.forEach((link) => {
    link.addEventListener('click', () => toggleMobileMenu(true));
  });

  window.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && mobileDrawer?.classList.contains('is-open')) {
      toggleMobileMenu(true);
    }
  });

  /* ==========================================================================
     11. BACK TO TOP BUTTON
     ========================================================================== */
  backToTopBtn?.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });

  /* ==========================================================================
     12. IMAGE FALLBACK ERROR HANDLING
     ========================================================================== */
  document.querySelectorAll('img').forEach((img) => {
    img.addEventListener('error', () => {
      img.style.display = 'none';
      const wrapper = img.parentElement;
      if (wrapper && !wrapper.querySelector('.avatar-fallback')) {
        const fallback = document.createElement('div');
        fallback.className = 'avatar-fallback';
        fallback.style.cssText = 'width:100%;height:100%;display:grid;place-items:center;background:rgba(20,13,38,0.8);color:#d8b4fe;font-family:var(--font-mono);font-size:0.75rem;';
        fallback.textContent = 'NXT';
        wrapper.appendChild(fallback);
      }
    });
  });

})();
