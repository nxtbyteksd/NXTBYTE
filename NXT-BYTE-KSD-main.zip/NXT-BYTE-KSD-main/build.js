#!/usr/bin/env node
/**
 * Nxt Byte Production Build & Verification Engine
 * Validates syntax, asset integrity, link correctness, and security prior to Git deployment.
 */

const fs = require('fs');
const path = require('path');
const vm = require('vm');

console.log('🚀 Starting Nxt Byte Production Build & Verification...');
const startTime = Date.now();
let errors = [];
let warnings = [];

// 1. File existence check
const requiredFiles = ['index.html', 'styles.css', 'script.js'];
for (const file of requiredFiles) {
  if (!fs.existsSync(file)) {
    errors.push(`Missing required production file: ${file}`);
  } else {
    const stats = fs.statSync(file);
    console.log(`  ✓ Verified ${file} (${(stats.size / 1024).toFixed(1)} KB)`);
  }
}

if (errors.length > 0) {
  console.error('\n❌ Build Failed:');
  errors.forEach(e => console.error(`  - ${e}`));
  process.exit(1);
}

// 2. HTML Validation & Asset Reference Checks
const html = fs.readFileSync('index.html', 'utf-8');

// Check asset references in index.html
const assetRegex = /src=["'](images\/[^"']+)["']/g;
let match;
let referencedAssets = new Set();
while ((match = assetRegex.exec(html)) !== null) {
  referencedAssets.add(match[1]);
}

console.log(`\n📦 Checking ${referencedAssets.size} referenced image assets...`);
for (const assetPath of referencedAssets) {
  const resolved = path.join(__dirname, assetPath);
  if (!fs.existsSync(resolved)) {
    errors.push(`Referenced asset not found: ${assetPath}`);
  } else {
    const size = fs.statSync(resolved).size;
    if (size === 0) {
      errors.push(`Referenced asset is empty: ${assetPath}`);
    } else {
      console.log(`  ✓ ${assetPath} (${(size / 1024).toFixed(1)} KB)`);
    }
  }
}

// Check Instagram links
const instagramRegex = /href=["'](https:\/\/www\.instagram\.com\/[^"']*)["']/g;
let instaMatches = [];
while ((match = instagramRegex.exec(html)) !== null) {
  instaMatches.push(match[1]);
}

const targetInstagram = 'https://www.instagram.com/ecellkmctcemksd/';
console.log(`\n🔗 Checking Instagram links (${instaMatches.length} found)...`);
for (const link of instaMatches) {
  if (link !== targetInstagram) {
    errors.push(`Invalid Instagram URL: ${link} (expected ${targetInstagram})`);
  }
}
if (instaMatches.length === 0) {
  errors.push('No Instagram link found in index.html');
} else {
  console.log(`  ✓ All ${instaMatches.length} Instagram touchpoints correctly target ${targetInstagram}`);
}

// 3. CSS Validation
console.log('\n🎨 Validating styles.css...');
const css = fs.readFileSync('styles.css', 'utf-8');
const openBraces = (css.match(/\{/g) || []).length;
const closeBraces = (css.match(/\}/g) || []).length;

if (openBraces !== closeBraces) {
  errors.push(`CSS syntax error: Mismatched braces (Open: ${openBraces}, Close: ${closeBraces})`);
} else {
  console.log(`  ✓ CSS braces balanced (${openBraces} rulesets verified)`);
}

// 4. JavaScript Syntax Validation
console.log('\n⚡ Validating script.js...');
const jsCode = fs.readFileSync('script.js', 'utf-8');
try {
  new vm.Script(jsCode);
  console.log('  ✓ script.js syntax compiled successfully');
} catch (err) {
  errors.push(`JavaScript compilation error in script.js: ${err.message}`);
}

// 5. Security & Hygiene Scan
console.log('\n🛡️ Scanning for security leaks and local paths...');
const checkFiles = [
  { name: 'index.html', content: html },
  { name: 'styles.css', content: css },
  { name: 'script.js', content: jsCode }
];

const prohibitedPatterns = [
  { pattern: /localhost(?::\d+)?/i, desc: 'Hard-coded localhost URL' },
  { pattern: /127\.0\.0\.1(?::\d+)?/, desc: 'Hard-coded loopback IP' },
  { pattern: /file:\/\//i, desc: 'Hard-coded local file URL' },
  { pattern: /(?:AIzaSy|sk-[a-zA-Z0-9]{20,}|ghp_[a-zA-Z0-9]{20,})/, desc: 'Exposed API/Secret key' },
  { pattern: /password\s*[:=]\s*["'][^"']+["']/i, desc: 'Hardcoded password string' }
];

for (const f of checkFiles) {
  for (const p of prohibitedPatterns) {
    if (p.pattern.test(f.content)) {
      errors.push(`Security violation in ${f.name}: ${p.desc}`);
    }
  }
}
console.log('  ✓ No exposed credentials, secrets, or localhost URLs detected');

// Final summary
const duration = Date.now() - startTime;
if (errors.length > 0) {
  console.error(`\n❌ Build failed with ${errors.length} error(s):`);
  errors.forEach(e => console.error(`  ✖ ${e}`));
  process.exit(1);
} else {
  console.log(`\n✨ Production Build Succeeded in ${duration}ms!`);
  console.log('   All assets and configurations are verified and production-ready for Git deployment.\n');
  process.exit(0);
}
