# Nxt Byte — Flagship Entrepreneurship Summit

> **Build What Comes Next.**  
> The premier campus venture launchpad turning ambitious student builders into venture-scale founders.  
> Organized by **E-Cell KMCTCEEM** in collaboration with **National Entrepreneurship Challenge (NEC) · IIT Bombay**.

Official Instagram: [@ecellkmctcemksd](https://www.instagram.com/ecellkmctcemksd/)

---

## Overview

Nxt Byte is a cinematic, high-performance web experience showcasing the flagship entrepreneurship summit. It features a custom 60+ FPS interactive 3D particle constellation canvas, gyroscope/mouse parallax tilt engines, prominent standalone brand logos without container boxes, and full responsive design from 320px mobile to ultra-wide displays.

### Key Highlights
- **Standalone Brand Identity**: Crisp, unboxed, high-resolution logos (Nxt Byte, E-Cell, and NEC IIT Bombay) displayed directly on the dark canvas with organic contour glow.
- **60+ FPS 3D Engine**: GPU-accelerated canvas particle constellation that automatically pauses when scrolled out of view.
- **Universal 3D Card Tilt**: Mouse-driven dynamic specular glare and 3D depth perspective across all interactive cards.
- **Production-Hardened**: Pre-configured for zero-config deployment on **Vercel**, **Netlify**, **GitHub Pages**, and **Cloudflare Pages**.
- **Social & SEO Ready**: Complete OpenGraph, Twitter Cards, preconnect headers, and accessible semantic HTML5 markup.
- **Zero Secrets**: Contains zero exposed credentials, API keys, or hardcoded local URLs.

---

## Project Structure

```
NXT-BYTE-KSD/
├── images/                   # Optimized, tight-cropped, high-res web assets (PNG/JPEG)
├── .gitignore                # Comprehensive Git ignore for production
├── .nojekyll                 # GitHub Pages asset routing configuration
├── 404.html                  # GitHub Pages SPA redirect fallback
├── build.js                  # Production build & verification script
├── index.html                # Main semantic landing page & SEO meta
├── netlify.toml              # Netlify deployment & security headers configuration
├── package.json              # Standard npm configuration & scripts
├── README.md                 # Project documentation & deployment guide
├── script.js                 # 3D canvas constellation & interactive tilt engine
├── styles.css                # Cinematic design tokens, animations, & media queries
├── test.js                   # Automated DOM, anchor, and link test suite
└── vercel.json               # Vercel SPA routing & security headers configuration
```

---

## Getting Started

### Prerequisites
- [Node.js](https://nodejs.org/) (version 18 or newer)
- npm (version 9 or newer)

### Local Setup

1. **Clone the repository**:
   ```bash
   git clone https://github.com/ecellkmctcemksd/nxt-byte.git
   cd nxt-byte
   ```

2. **Install local development dependencies**:
   ```bash
   npm install
   ```

3. **Start the local development server**:
   ```bash
   npm run dev
   ```
   Open [http://localhost:3000](http://localhost:3000) in your browser.

4. **Run the production build & validation check**:
   ```bash
   npm run build
   ```

5. **Run the automated test suite**:
   ```bash
   npm test
   ```

---

## Production Deployment Guides

This project is pre-configured and 100% ready for Git-based deployment on all major hosting providers.

### Option 1: Deploy to Vercel (Recommended)

1. Push your code to a Git repository (GitHub / GitLab / Bitbucket).
2. Visit [Vercel](https://vercel.com/) and click **"Add New Project"**.
3. Import the `nxt-byte` repository.
4. Leave settings as default (Vercel automatically detects `vercel.json` and runs `npm run build`).
5. Click **"Deploy"**.

*Or using the Vercel CLI:*
```bash
npx vercel --prod
```

---

### Option 2: Deploy to Netlify

1. Push your code to GitHub.
2. Log in to [Netlify](https://www.netlify.com/) and click **"Add new site" > "Import an existing project"**.
3. Select your repository.
4. Netlify will automatically read `netlify.toml` with:
   - **Build command**: `npm run build`
   - **Publish directory**: `.`
5. Click **"Deploy site"**.

*Or using the Netlify CLI:*
```bash
npx netlify deploy --prod
```

---

### Option 3: Deploy to GitHub Pages

1. In your GitHub repository, navigate to **Settings > Pages**.
2. Under **Build and deployment > Source**, select **Deploy from a branch**.
3. Select the `main` branch and `/ (root)` folder.
4. Click **Save**.
5. The included `.nojekyll` and `404.html` files ensure all assets load cleanly and SPA routes redirect properly.

---

### Option 4: Deploy to Cloudflare Pages

1. Log in to the Cloudflare Dashboard and navigate to **Workers & Pages > Create application > Pages**.
2. Connect your Git repository.
3. Set **Build command** to: `npm run build`
4. Set **Build output directory** to: `.`
5. Click **Save and Deploy**.

---

## Verification & Quality Assurance

Every deployment is verified against the automated build engine:
- `npm run build`: Validates that all 16 referenced images exist and are non-empty, checks CSS brace balance, compiles JavaScript, scans for accidental secret leaks, and validates Instagram links.
- `npm test`: Runs automated assertions verifying DOCTYPE, viewport tags, navigation anchor targets, standalone logo classes, and canvas initialization.

---

## Affiliations & Credits

- **Organized By**: Entrepreneurship Cell, KMCT College of Engineering for Emerging Technologies & Management (KMCTCEEM).
- **Collaborating Partner**: National Entrepreneurship Challenge (NEC), IIT Bombay.
- **Instagram**: [https://www.instagram.com/ecellkmctcemksd/](https://www.instagram.com/ecellkmctcemksd/)

---

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.
