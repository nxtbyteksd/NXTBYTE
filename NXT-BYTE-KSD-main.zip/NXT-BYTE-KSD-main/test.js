#!/usr/bin/env node
/**
 * Nxt Byte Automated Test Suite
 * Validates DOM anchors, logo elements, responsive meta tags, and script references.
 */

const fs = require('fs');
const assert = require('assert');

console.log('🧪 Running Nxt Byte Test Suite...\n');
let testsPassed = 0;

function it(name, fn) {
  try {
    fn();
    console.log(`  ✓ PASS: ${name}`);
    testsPassed++;
  } catch (err) {
    console.error(`  ✖ FAIL: ${name}`);
    console.error(`    ${err.message}`);
    process.exit(1);
  }
}

const html = fs.readFileSync('index.html', 'utf-8');

it('HTML contains valid DOCTYPE and html lang attribute', () => {
  assert(html.startsWith('<!doctype html>') || html.startsWith('<!DOCTYPE html>'), 'Missing DOCTYPE');
  assert(html.includes('<html lang="en">'), 'Missing <html lang="en">');
});

it('Responsive viewport and theme-color meta tags are set', () => {
  assert(html.includes('name="viewport"'), 'Missing viewport meta tag');
  assert(html.includes('name="theme-color"'), 'Missing theme-color meta tag');
});

it('All navigation href anchors resolve to existing section IDs in the DOM', () => {
  const anchorRegex = /href=["']#([a-zA-Z0-9_\-]+)["']/g;
  let match;
  const anchors = new Set();
  while ((match = anchorRegex.exec(html)) !== null) {
    anchors.add(match[1]);
  }

  for (const id of anchors) {
    if (id === 'top') {
      assert(html.includes('id="top"'), `Anchor target id="${id}" not found`);
    } else {
      assert(html.includes(`id="${id}"`), `Anchor target id="${id}" not found in DOM`);
    }
  }
});

it('All 5 logo touchpoints (Header, Hero, Ecosystem, Mobile, Footer) exist without containers', () => {
  assert(html.includes('class="brand-logo-img"'), 'Missing standalone header brand logo');
  assert(html.includes('class="hero-standalone-logo"'), 'Missing standalone hero logo');
  assert(html.includes('class="eco-standalone-logo eco-standalone-logo--ecell"'), 'Missing ecosystem E-Cell logo');
  assert(html.includes('class="eco-standalone-logo eco-standalone-logo--nec"'), 'Missing ecosystem NEC logo');
  assert(html.includes('class="footer-brand-logo-img"'), 'Missing standalone footer brand logo');
});

it('No obsolete logo box/container classes exist in index.html', () => {
  const forbiddenClasses = [
    'hero-brand-lockup',
    'hero-emblem-glass',
    'hero-emblem-orbital-ring',
    'brand-logo-container',
    'eco-logo-badge',
    'eco-logo-frame',
    'footer-brand-logo-container'
  ];
  for (const cls of forbiddenClasses) {
    assert(!html.includes(cls), `Found obsolete container class in index.html: ${cls}`);
  }
});

it('Canvas 3D constellation element is present and configured', () => {
  assert(html.includes('id="hero3DCanvas"'), 'Missing #hero3DCanvas for 3D graphics');
});

it('External scripts and stylesheets are linked correctly', () => {
  assert(html.includes('rel="stylesheet" href="styles.css"'), 'Missing styles.css link');
  assert(html.includes('src="script.js"'), 'Missing script.js script tag');
});

console.log(`\n🎉 All ${testsPassed} tests passed successfully!\n`);
process.exit(0);
